import setuptools

setuptools.setup(
    name="B2OPT",
    version="1.0.0",
    author="EUREKA",
    author_email="2621843957@qq.com",
    description="",
    long_description="CODE OF B2OPT",
    long_description_content_type="text",
    url="",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
